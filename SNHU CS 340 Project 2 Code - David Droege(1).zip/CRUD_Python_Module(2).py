# Example Python Code to Insert a Document 

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB."""

    def __init__(self):
        """Initialize MongoClient to access the aac database, shelter_outcomes collection.

        Connection uses aacuser credentials. Update PASS for your environment.
        """
        # Connection Variables
        USER = 'aacuser'
        PASS = 'SNHUDavidDroege'
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'  # Updated to match imported CSV collection
        # Initialize Connection
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER, PASS, HOST, PORT))
        self.database = self.client[DB]
        self.collection = self.database[COL]
        
    # Create a method to return the next available record number for use in the create method
    def get_next_rec_num(self):
        """Generate the next available record number for a new document."""
        try:
            # Find document with highest record_number
            latest_doc = self.collection.find_one(sort=[('rec_num', -1)])
            if latest_doc and 'rec_num' in latest_doc:
                return latest_doc['rec_num'] + 1
            return 1  # Start at 1 if no record numbers exist
        except Exception:
            return None

    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        """Insert a document into the shelter_outcomes collection.

        Args:
            data: Dictionary of key/value pairs to insert as a document.

        Returns:
            bool: True if insertion is successful, False otherwise.

        Raises:
            Exception: If data parameter is empty.
        """
        if data is not None:
            try:
                # Add record_number if not provided
                if 'rec_num' not in data:
                    data['rec_num'] = self.get_next_rec_num()
                    if data['rec_num'] is None:
                        return False
                result = self.co.insert_one(data)
                return result.acknowledged
            except Exception:
                return False
        else:
            raise Exception('Nothing to save, because data parameter is empty')

    # Create method to implement the R in CRUD
    def read(self, query):
        """Query documents from the shelter_outcomes collection.

        Args:
            query: Dictionary of key/value pairs for the query filter.

        Returns:
            list: List of matching documents, or empty list if query fails.
        """
        try:
            # Use find() to query documents and convert cursor to list
            return list(self.collection.find(query))
        except Exception:
            return []

    # Create Method to implement the U in CRUD
    def update(self, query, update_data):
        """Update documents in the shelter_outcomes collection matching the query.

        Args:
            query: Dictionary of key/value pairs for the query filter (e.g., {'rec_num': 123}).
            update_data: Dictionary for the update operation (e.g., {'$set': {'age': 2}}).

        Returns:
            int: Number of documents modified, or 0 if update fails.
        """
        try:
            result = self.collection.update_many(query, update_data)
            return result.modified_count
        except Exception:
            return 0

    # Method to implement the D in CRUD
    def delete(self, query):
        """Delete documents from the shelter_outcomes collection matching the query.

        Args:
            query: Dictionary of key/value pairs for the query filter (e.g., {'rec_num': 123}).

        Returns:
            int: Number of documents deleted, or 0 if deletion fails.
        """
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception:
            return 0